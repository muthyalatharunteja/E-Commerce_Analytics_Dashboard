#tEST Revenue Check
SELECT SUM(total_price) AS total_revenue
FROM `ecommerce-data-project-494008.ecommerce_analytics.fact_orders`;