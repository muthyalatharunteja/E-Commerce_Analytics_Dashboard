CREATE OR REPLACE TABLE `ecommerce-data-project-494008.ecommerce_analytics.kpi_delivery_vs_value` AS
SELECT
  cs.customer_segment,
  AVG(dp.delivery_days) AS avg_delivery,
  SUM(dp.is_delayed) * 100.0 / COUNT(*) AS delay_rate

FROM `ecommerce-data-project-494008.ecommerce_analytics.delivery_performance` dp
JOIN `ecommerce-data-project-494008.ecommerce_analytics.kpi_customer_segments` cs
ON dp.customer_id = cs.customer_id

GROUP BY cs.customer_segment;
