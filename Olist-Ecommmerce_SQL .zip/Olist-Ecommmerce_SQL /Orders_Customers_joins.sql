#Test 1: Orders ↔ Customers
SELECT o.order_id, c.customer_id
FROM `ecommerce-data-project-494008.ecommerce_raw.orders` o
JOIN `ecommerce-data-project-494008.ecommerce_raw.customers` c
ON o.customer_id = c.customer_id
LIMIT 10;