#Time analysis
CREATE OR REPLACE TABLE `ecommerce-data-project-494008.ecommerce_analytics.kpi_time_analysis` AS
SELECT
  EXTRACT(HOUR FROM order_date) AS hour,
  EXTRACT(DAYOFWEEK FROM order_date) AS day_of_week,
  COUNT(*) AS orders
FROM `ecommerce-data-project-494008.ecommerce_analytics.fact_orders`
GROUP BY hour, day_of_week;

SELECT * 
FROM `ecommerce-data-project-494008.ecommerce_analytics.kpi_time_analysis`