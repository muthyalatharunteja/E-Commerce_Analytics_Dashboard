# Order Items ↔ Products
SELECT oi.product_id, p.product_category_name
FROM `ecommerce-data-project-494008.ecommerce_raw.order_items` oi
JOIN `ecommerce-data-project-494008.ecommerce_raw.products` p
ON oi.product_id = p.product_id
LIMIT 10;