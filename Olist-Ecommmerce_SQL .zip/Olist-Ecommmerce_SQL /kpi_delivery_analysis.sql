#DELIVERY ANALYSIS
CREATE OR REPLACE TABLE `ecommerce-data-project-494008.ecommerce_analytics.delivery_performance` AS
SELECT
  order_id,
  order_date,
  order_delivered_customer_date,
  order_estimated_delivery_date,

  DATE_DIFF(order_delivered_customer_date, order_date, DAY) AS delivery_days,

  CASE 
    WHEN order_delivered_customer_date > order_estimated_delivery_date THEN 1
    ELSE 0
  END AS is_delayed

FROM `ecommerce-data-project-494008.ecommerce_staging.stg_orders`
WHERE order_delivered_customer_date IS NOT NULL;