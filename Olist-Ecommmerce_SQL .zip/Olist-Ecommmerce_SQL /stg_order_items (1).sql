CREATE OR REPLACE TABLE `ecommerce-data-project-494008.ecommerce_staging.stg_order_items` AS
SELECT
  order_id,
  product_id,
  seller_id,
  price,
  freight_value,
  (price + freight_value) AS total_price
FROM `ecommerce-data-project-494008.ecommerce_raw.order_items`
WHERE order_id IS NOT NULL;
