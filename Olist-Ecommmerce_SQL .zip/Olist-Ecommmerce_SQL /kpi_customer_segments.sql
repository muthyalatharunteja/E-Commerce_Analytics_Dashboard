# kpi_customer_segments

CREATE OR REPLACE TABLE `ecommerce-data-project-494008.ecommerce_analytics.kpi_customer_segments` AS
SELECT
  customer_id,
  SUM(total_price) AS total_spent,
  CASE 
    WHEN SUM(total_price) > 1000 THEN 'High Value'
    WHEN SUM(total_price) > 500 THEN 'Medium Value'
    ELSE 'Low Value'
  END AS customer_segment
FROM `ecommerce-data-project-494008.ecommerce_analytics.fact_orders`
GROUP BY customer_id;

SELECT * 
FROM `ecommerce-data-project-494008.ecommerce_analytics.kpi_customer_segments`