CREATE OR REPLACE TABLE `ecommerce-data-project-494008.ecommerce_staging.stg_payments` AS
SELECT
  order_id,
  payment_type,
  payment_value
FROM `ecommerce-data-project-494008.ecommerce_raw.payments`
WHERE order_id IS NOT NULL;