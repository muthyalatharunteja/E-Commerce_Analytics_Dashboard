CREATE OR REPLACE TABLE `ecommerce-data-project-494008.ecommerce_staging.stg_customers` AS
SELECT
  customer_id,
  customer_unique_id AS customer_uid,
  customer_city,
  customer_state
FROM `ecommerce-data-project-494008.ecommerce_raw.customers`
WHERE customer_id IS NOT NULL;
