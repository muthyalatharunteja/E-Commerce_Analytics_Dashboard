# kpi_product_performance
CREATE OR REPLACE TABLE `ecommerce-data-project-494008.ecommerce_analytics.kpi_product_performance` AS
SELECT
  product_id,
  COUNT(*) AS total_sales,
  SUM(total_price) AS total_revenue
FROM `ecommerce-data-project-494008.ecommerce_analytics.fact_orders`
GROUP BY product_id
ORDER BY total_revenue DESC;

SELECT * 
FROM `ecommerce-data-project-494008.ecommerce_analytics.kpi_product_performance`