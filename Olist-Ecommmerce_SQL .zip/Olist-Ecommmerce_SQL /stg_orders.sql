CREATE OR REPLACE TABLE `ecommerce-data-project-494008.ecommerce_staging.stg_orders` AS
SELECT
  order_id,
  customer_id,
  order_status,
  order_purchase_timestamp AS order_date,
  order_approved_at,
  order_delivered_carrier_date,
  order_delivered_customer_date,
  order_estimated_delivery_date
FROM `ecommerce-data-project-494008.ecommerce_raw.orders`
WHERE order_id IS NOT NULL;

SELECT * 
FROM `ecommerce-data-project-494008.ecommerce_staging.stg_orders`
LIMIT 10;