#Products Dimension
CREATE OR REPLACE TABLE `ecommerce-data-project-494008.ecommerce_analytics.dim_products` AS
SELECT
  product_id,
  product_category,
  product_weight_g
FROM `ecommerce-data-project-494008.ecommerce_staging.stg_products`;