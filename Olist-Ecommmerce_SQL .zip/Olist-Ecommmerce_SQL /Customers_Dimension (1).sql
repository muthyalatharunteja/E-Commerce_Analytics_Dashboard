#Customers Dimension
CREATE OR REPLACE TABLE `ecommerce-data-project-494008.ecommerce_analytics.dim_customers` AS
SELECT
  customer_id,
  customer_uid,
  customer_city,
  customer_state
FROM `ecommerce-data-project-494008.ecommerce_staging.stg_customers`;