#kpi_delivery_performance

CREATE OR REPLACE TABLE `ecommerce-data-project-494008.ecommerce_analytics.kpi_delivery_performance` AS
SELECT
  AVG(DATE_DIFF(order_delivered_customer_date, order_date, DAY)) AS avg_delivery_days,
  SUM(
    CASE 
      WHEN order_delivered_customer_date > order_estimated_delivery_date THEN 1
      ELSE 0
    END
  ) * 100.0 / COUNT(*) AS delay_percentage
FROM `ecommerce-data-project-494008.ecommerce_staging.stg_orders`
WHERE order_delivered_customer_date IS NOT NULL;

SELECT * 
FROM `ecommerce-data-project-494008.ecommerce_analytics.kpi_delivery_performance`