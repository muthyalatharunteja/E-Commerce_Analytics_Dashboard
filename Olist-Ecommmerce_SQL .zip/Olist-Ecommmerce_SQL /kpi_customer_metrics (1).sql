#kpi_customer_metrics
CREATE OR REPLACE TABLE `ecommerce-data-project-494008.ecommerce_analytics.kpi_customer_metrics` AS
SELECT
  customer_id,
  COUNT(DISTINCT order_id) AS total_orders,
  SUM(total_price) AS total_spent
FROM `ecommerce-data-project-494008.ecommerce_analytics.fact_orders`
GROUP BY customer_id;

SELECT * 
FROM `ecommerce-data-project-494008.ecommerce_analytics.kpi_customer_metrics`