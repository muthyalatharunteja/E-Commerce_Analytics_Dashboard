# Test Fact + Products
SELECT 
  f.product_id,
  p.product_category,
  f.total_price
FROM `ecommerce-data-project-494008.ecommerce_analytics.fact_orders` f
JOIN `ecommerce-data-project-494008.ecommerce_analytics.dim_products` p
ON f.product_id = p.product_id
LIMIT 10;