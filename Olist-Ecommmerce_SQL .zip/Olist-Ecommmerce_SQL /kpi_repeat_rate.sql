# kpi_repeat_rate

#kpi_repeat_rate
CREATE OR REPLACE TABLE `ecommerce-data-project-494008.ecommerce_analytics.kpi_repeat_rate` AS
WITH customer_orders AS (
  SELECT 
    c.customer_uid,
    COUNT(DISTINCT f.order_id) AS order_count
  FROM `ecommerce-data-project-494008.ecommerce_analytics.fact_orders` f
  JOIN `ecommerce-data-project-494008.ecommerce_analytics.dim_customers` c
  ON f.customer_id = c.customer_id
  GROUP BY c.customer_uid
)

SELECT
  ROUND(
    (COUNTIF(order_count > 1) * 100.0) / COUNT(*),
    2
  ) AS repeat_customer_rate
FROM customer_orders;