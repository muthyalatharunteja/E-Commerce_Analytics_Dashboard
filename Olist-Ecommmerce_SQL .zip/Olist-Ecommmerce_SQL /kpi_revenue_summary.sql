#Revenue Summary (Core KPI)
CREATE OR REPLACE TABLE `ecommerce-data-project-494008.ecommerce_analytics.kpi_revenue_summary` AS
SELECT
  EXTRACT(YEAR FROM order_date) AS year,
  EXTRACT(MONTH FROM order_date) AS month,
  SUM(total_price) AS total_revenue,
  COUNT(DISTINCT order_id) AS total_orders,
  AVG(total_price) AS avg_order_value
FROM `ecommerce-data-project-494008.ecommerce_analytics.fact_orders`
GROUP BY year, month
ORDER BY year, month;

SELECT * 
FROM `ecommerce-data-project-494008.ecommerce_analytics.kpi_revenue_summary`