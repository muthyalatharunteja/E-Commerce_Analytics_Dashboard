# Date Dimension
CREATE OR REPLACE TABLE `ecommerce-data-project-494008.ecommerce_analytics.dim_date` AS
SELECT DISTINCT
  order_date,
  EXTRACT(YEAR FROM order_date) AS year,
  EXTRACT(MONTH FROM order_date) AS month
FROM `ecommerce-data-project-494008.ecommerce_staging.stg_orders`;