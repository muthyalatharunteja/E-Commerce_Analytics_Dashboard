# Test Your Model

# Join Fact + Customer 
SELECT f.order_id, d.customer_city
FROM `ecommerce-data-project-494008.ecommerce_analytics.fact_orders` f
JOIN `ecommerce-data-project-494008.ecommerce_analytics.dim_customers` d
ON f.customer_id = d.customer_id
LIMIT 10;