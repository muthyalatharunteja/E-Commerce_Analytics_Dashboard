#kpi_rfm
CREATE OR REPLACE TABLE `ecommerce-data-project-494008.ecommerce_analytics.kpi_rfm` AS
SELECT
  c.customer_uid,

  DATE_DIFF(
    CURRENT_DATE(),
    DATE(MAX(o.order_date)),
    DAY
  ) AS recency,

  COUNT(DISTINCT o.order_id) AS frequency,
  SUM(o.total_price) AS monetary

FROM `ecommerce-data-project-494008.ecommerce_analytics.fact_orders` o
JOIN `ecommerce-data-project-494008.ecommerce_analytics.dim_customers` c
ON o.customer_id = c.customer_id

GROUP BY c.customer_uid;

SELECT * 
FROM `ecommerce-data-project-494008.ecommerce_analytics.kpi_rfm`