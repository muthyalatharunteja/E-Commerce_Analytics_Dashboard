CREATE OR REPLACE TABLE `ecommerce-data-project-494008.ecommerce_staging.stg_products` AS
SELECT
  product_id,
  product_category_name AS product_category,
  product_weight_g,
  product_length_cm,
  product_height_cm,
  product_width_cm
FROM `ecommerce-data-project-494008.ecommerce_raw.products`
WHERE product_id IS NOT NULL;
