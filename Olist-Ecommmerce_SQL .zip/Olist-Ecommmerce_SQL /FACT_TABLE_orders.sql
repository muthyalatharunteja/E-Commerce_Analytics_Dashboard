#FACT TABLE
CREATE OR REPLACE TABLE `ecommerce-data-project-494008.ecommerce_analytics.fact_orders` AS
SELECT
  o.order_id,
  o.customer_id,
  oi.product_id,
  o.order_date,
  oi.price,
  oi.freight_value,
  oi.total_price
FROM `ecommerce-data-project-494008.ecommerce_staging.stg_orders` o
JOIN `ecommerce-data-project-494008.ecommerce_staging.stg_order_items` oi
ON o.order_id = oi.order_id;