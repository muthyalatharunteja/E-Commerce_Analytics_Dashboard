#Cohort Analysis
-- 📌 Cohort Analysis Table (Window Function Based)

CREATE OR REPLACE TABLE 
`ecommerce-data-project-494008.ecommerce_analytics.kpi_cohort_analysis` AS

WITH base AS (
  SELECT
    c.customer_uid,
    o.order_id,

    -- Convert to date
    DATE(o.order_date) AS order_date,

    -- 🔥 Window function: first purchase date per customer
    MIN(DATE(o.order_date)) 
      OVER (PARTITION BY c.customer_uid) AS first_order_date

  FROM `ecommerce-data-project-494008.ecommerce_analytics.fact_orders` o
  JOIN `ecommerce-data-project-494008.ecommerce_analytics.dim_customers` c
    ON o.customer_id = c.customer_id
),

cohort_data AS (
  SELECT
    customer_uid,
    order_id,

    -- Cohort month (first purchase month)
    DATE_TRUNC(first_order_date, MONTH) AS cohort_month,

    -- Order month
    DATE_TRUNC(order_date, MONTH) AS order_month,

    -- Month difference
    DATE_DIFF(
      DATE_TRUNC(order_date, MONTH),
      DATE_TRUNC(first_order_date, MONTH),
      MONTH
    ) AS month_number

  FROM base
)

SELECT
  cohort_month,
  order_month,
  month_number,
  COUNT(DISTINCT customer_uid) AS customers

FROM cohort_data
GROUP BY cohort_month, order_month, month_number
ORDER BY cohort_month, month_number;
SELECT * 
FROM `ecommerce-data-project-494008.ecommerce_analytics.kpi_cohort_analysis`