# PRODUCT DEPENDENCY RISK
CREATE OR REPLACE TABLE `ecommerce-data-project-494008.ecommerce_analytics.kpi_top_products` AS
SELECT
  product_id,
  SUM(total_price) AS revenue
FROM `ecommerce-data-project-494008.ecommerce_analytics.fact_orders`
GROUP BY product_id
ORDER BY revenue DESC;

SELECT * 
FROM `ecommerce-data-project-494008.ecommerce_analytics.kpi_top_products`